def main():
    print("Hello from my-poetry-project!")

if __name__ == "__main__":
    main()
