def main():
    print("Hello from my-poetry-project v1.1!")

if __name__ == "__main__":
    main()
